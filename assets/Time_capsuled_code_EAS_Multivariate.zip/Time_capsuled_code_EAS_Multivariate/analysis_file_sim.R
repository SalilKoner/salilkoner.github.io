
args     <- commandArgs(TRUE)
Exper    <- as.integer(args[1])

print(paste0("Working for experiment: ", Exper))

sim.result <- array(NA,dim=c(11,12,1000))

for (dsn in 1:1000){
  filename         <-  paste0("Results/Experiment", Exper, "/output_f", Exper, "_dsn", dsn, ".Rdata")
  if (file.exists(filename)){
    load(filename)
    res    <- get(paste0("output_f", Exper, "_dsn", dsn))
    sim.result[, , dsn] <- res
  }
}

Summary.mean   <- round(apply(sim.result, c(1,2), mean, na.rm=T),4)
Summary.median <- round(apply(sim.result, c(1,2), median, na.rm=T),4)

colnames(Summary.mean)    <- colnames(Summary.median) <- c("CV.OLS.OLS", "CV.OLS.BMA", "CV.BMA.OLS", "CV.BMA.BMA", 
                                                         "BIC.OLS.OLS", "BIC.OLS.BMA", "MBSP", "SRRR", "SPLS", "MLASSO", 
                                                         "MSGLASSO", "MBGLSS") 

rownames(Summary.mean)    <- rownames(Summary.median)   <- c("Err.B", "Est.Err.inSample", "Pred.Err.inSample",
                                                             "Est.Err.outSample", "Pred.Err.outSample", 
                                                             "FDR", "FNR", "MP", "Prob.TrueModel", "isTrueModelMAP?",
                                                             "time (in seconds)")


save(list=c("Summary.mean", "Summary.median"), file=paste0("Results/Experiment", Exper, "/Summary_f", Exper, ".Rdata"))


print(t(Summary.mean)[,c(1,3,5,6:10)])
print(t(Summary.median)[,c(1,3,5,6:10)])
