#!/bin/bash


for i in {1..6}
do
mkdir -p Results/Experiment$i
done

# Simulation results
# Generate the synthetic data and implement the estimation procedures
# This for-loop is most efficiently run in parallelon a computing cluster
# In parallel it will take approximately 1 day to finish the simulation 
for i in {1..1000} 
do

# Experiment 1
Rscript final_runfile_sim.R $i 8 1 0.05 10 24 10
# Experiment 2
Rscript final_runfile_sim.R $i 8 2 0.05 10 24 10
# Experiment 3
Rscript final_runfile_sim.R $i 8 3 0.05 10 24 10
# Experiment 4
Rscript final_runfile_sim.R $i 8 4 0.05 10 24 10
# Experiment 5
Rscript final_runfile_sim.R $i 8 5 0.05 10 24 10
# Experiment 6
Rscript final_runfile_sim.R $i 8 6 0.05 10 24 10

done


# Produce the summary statistics in Table 1 from the 1000 generated datasets
for i in {1..6}
do
Rscript analysis_file_sim.R $i
done
